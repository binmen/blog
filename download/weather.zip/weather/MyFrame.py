﻿#! /usr/bin/env python
#coding=utf-8
import wx
from GetWeather import WeatherInfo
#todayInfo=u"12月8日星期四 小雨转多云7℃/-1℃ 北风5-6级 img/07.gif img/01.gif".split()
#daysInfo=[todayInfo,todayInfo,todayInfo,todayInfo]      
class MyApp(wx.App):
    """应用程序类wx.App的子类"""
    def __init__(self, title, sText):    #重构构造方法，其中title、sText分别是传递给主窗口的标题参数和状态栏参数
        wx.App.__init__(self)   #调用wx.App的构造方法
        frame = MyFrame(title, sText)   #创建主窗口对象
        frame.Show(True)    #显示主窗口
        
class MyFrame(wx.Frame):
    def __init__(self, title, sText):
        wx.Frame.__init__(self, None, -1, title=title, size=(500,500))
        self.panel = wx.Panel(self)
        stBar = self.CreateStatusBar()  #创建状态栏
        stBar.SetStatusText(sText)  #状态栏显示发布时间
     
        hdLeft = self.LayoutHeadLeft(todayInfo)
        hdRight = self.LayoutHeadRight()
        head = self.LayoutHead(hdLeft, hdRight)
        days = self.LayoutDaysWeather(daysInfo)
        sizer = self.LayoutPanel(head,days)
        
        self.panel.SetSizer(sizer)
        sizer.Fit(self)
        sizer.SetSizeHints(self)
        
    def LayoutHeadLeft(self, todayInfo):
        tLbl = wx.StaticText(self.panel, -1, label=todayInfo)
        
        #从文件载入图像
        img1 = wx.Image("C:/Users/Administrator/Desktop/weather/img/a_" +todayInfoo+"gif",wx.BITMAP_TYPE_GIF)
       
        
        #转换为静态图像控件
        sb1 = wx.StaticBitmap(self.panel, -1, wx.BitmapFromImage(img1))
        
        
        #使用GridBagSizer来放置两个图片和两个文本控件
        GBSizer = wx.GridBagSizer(vgap=5, hgap=5)   #Grid之间水平、竖直方向间距都是5个像素
        GBSizer.Add(sb1, pos=(0, 0), span=(1, 1), flag=0)   #天气图片1，放置在第1行第1列，占一行一列
        
        GBSizer.Add(tLbl, pos=(1, 0), span=(1, 2), flag=0)  #天气文字信息，放置在第2行第1列，占一行两列
                
        #再使用Static Box Sizer来放置上面的GridBagSizer
        sbox = wx.StaticBox(self.panel, -1,u'天气情况')        
        sbsizer = wx.StaticBoxSizer(sbox, wx.VERTICAL)
        sbsizer.Add(GBSizer,0, wx.ALL, 2)
        
        return sbsizer
    
    def LayoutHeadRight(self):
        tLbl = wx.StaticText(self.panel, -1, label=u'版权所有')
        tLb2 = wx.StaticText(self.panel, -1, label=u'Powered BY MB')
        GBSizer = wx.GridBagSizer(vgap=5, hgap=5)   #Grid之间水平、竖直方向间距都是5个像素
        GBSizer.Add(tLbl, pos=(1, 0), span=(1, 1), flag=0)  #天气文字信息，放置在第2行第1列，占一行两列       
        GBSizer.Add(tLb2, pos=(2, 0), span=(1, 1), flag=0)  #天气文字信息，放置在第2行第1列，占一行两列
                
        #再使用Static Box Sizer来放置上面的GridBagSizer
        sbox = wx.StaticBox(self.panel, -1,'')        
        sbsizer = wx.StaticBoxSizer(sbox, wx.VERTICAL)
        sbsizer.Add(GBSizer,0, wx.ALL, 2)
        
        return sbsizer
    def LayoutHead(self, headLeft,headRight):
        
        box = wx.BoxSizer(wx.HORIZONTAL)    #使用水平BoxSizer放置今日天气信息和3个按钮
        box.Add(headLeft, 1, flag=wx.EXPAND)
        box.Add(headRight, flag=wx.EXPAND)
        
        return box
    
    def LayoutDayWeather(self, dayInfo):
        """放置未来4天每天的天气信息"""
        #两个静态文本控件
        dLbl = wx.StaticText(self.panel, -1, label=dayInfo)
       #wLbl=wx.StaticText(self.panel,-1,label=todayInfo[2])
                
        
                
        #使用GridBagSizer来放置两个图片和两个文本控件
        GBSizer = wx.GridBagSizer(vgap=5, hgap=5)
        GBSizer.Add(dLbl, pos=(0, 0), span=(2,2), flag=wx.EXPAND)
        
        
        return GBSizer
    
    def LayoutDaysWeather(self, daysInfo):
        """使用竖直方向的StaticBoxSizer放置未来4天的天气信息"""
        sbox = wx.StaticBox(self.panel, -1, u"PM2.5情况")
        sbsizer = wx.StaticBoxSizer(sbox, wx.VERTICAL)
        for dayInfo in daysInfo:
            sz = self.LayoutDayWeather(dayInfo)
            sbsizer.Add(sz, flag=wx.EXPAND)
        return sbsizer
    
    def LayoutPanel(self, head, days):
        """使用竖直方向的BoxSizer放置窗口上半部分内容和下半部分内容"""
        bsizer = wx.BoxSizer(wx.VERTICAL)
        bsizer.Add(head, flag=wx.EXPAND)
        bsizer.Add(days, flag=wx.EXPAND)
        return bsizer


if __name__ == "__main__":

    #大连天气
    wInfo = WeatherInfo('http://www.pm25.com/dalian.html').getweather()
    #发布时间
    waysInfo =wInfo[5]
    wTitle = wInfo[0]   #大连天气预报
    wTime = wInfo[2]    #发布时间
    todayInfo = wInfo[6]
    todayInfoo = wInfo[1]  #今日天气信息
    daysInfo = wInfo[3:6]  
    app = MyApp(wTitle, wTime)  #应用程序类的一个实例
    app.MainLoop()  #进入主循环

   
