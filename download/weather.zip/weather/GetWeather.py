﻿# -*- coding: UTF-8 -*-  
from BeautifulSoup import BeautifulSoup    # For processing HTML  
from bs4 import BeautifulSoup
import re
from urllib import urlopen  
import sys
from time import ctime
reload(sys) 
sys.setdefaultencoding('utf-8')  
 
class WeatherInfo:  
    """Weather class"""  
    def __init__(self,site):  
        self.site = site  
        return  
      
    def getweather(self):  
        """Get the weather information from the Internet"""  
        text = urlopen(self.site).read()    #Get the source code of the site  
        soup = BeautifulSoup(text)    #Get the soup  
        city = soup.find(class_ = 'bi_loaction_city')   # 城市名称
        aqi = soup.find("a",{"class","bi_aqiarea_num"})  # AQI指数
        quality = soup.find("p",class_='bi_aqiarea_right')  # 空气质量等级
        result = soup.find("div",class_ ='bi_aqiarea_bottom')   # 空气质量描述
        tianqi = soup.find("p",class_='bi_info_weather')
        tim= re.compile('数据来源：中国环境监测总站&nbsp;&nbsp;&nbsp;&nbsp;最后更新：(.*)</p>')
        img1= re.compile('src="http://p1.qhimg.com/d/_hao360/weather/(.*)png" title=')
        a = city.get_text()
        b = aqi.get_text()
        c=quality.get_text()
        cc='空气质量等级'+c
        d = result.get_text()
        e=tianqi.get_text()
        timee= tim.findall(text)[0]
        time=u'更新时间： '+timee
        img2= img1.findall(text)[0]
        weather=[a,img2,time,d,cc,b,e]
        return  weather
       
            
if __name__ == '__main__':
    myWeather = WeatherInfo('http://www.pm25.com/dalian.html')
    myWeather.getweather()
