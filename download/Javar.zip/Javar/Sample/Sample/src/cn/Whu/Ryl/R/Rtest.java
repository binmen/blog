package cn.Whu.Ryl.R;
//����Java����R�ر��İ�;
import org.rosuda.REngine.REXPMismatchException;
import org.rosuda.REngine.REngineException;
import org.rosuda.REngine.Rserve.*;
import rserver.function.RService;
import org.rosuda.REngine.REXP;
//######################################
import java.awt.FlowLayout;
import javax.swing.ImageIcon; 
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JTextArea; 
import javax.swing.JScrollPane; 
import javax.swing.JLabel;
import javax.swing.JToolBar;
import java.io.File;
import java.awt.*;
import java.awt.event.*;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.BufferedReader;  
import java.io.BufferedWriter;  
import java.io.FileInputStream;  
import java.io.FileOutputStream;  
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;  
import java.io.InputStreamReader;  
import java.io.OutputStream;  
import java.io.OutputStreamWriter;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import java.io.File;
/////////////////////
import javax.imageio.ImageIO;
import javax.imageio.ImageReadParam;
import javax.imageio.ImageReader;
import javax.imageio.stream.ImageInputStream;
//////////////////////
public class Rtest extends JFrame{
	private JLabel jLabel1 = new JLabel();
	public  JTextArea show=new JTextArea("�ȴ���������...",8,57);
    final JTextArea hc=new JTextArea();
    final JTextArea hc1=new JTextArea();
    private JMenuBar mb;        //�˵���  
    private JMenu fileMenu;     //�ļ��˵� 
    private JMenu fileMenu1;   //ͼƬ��ʾ 
    private JMenu helpMenu;   //�����˵� 
    private JMenuItem fileMenuRun,fileMenucp,fileMenuNMSE,fileMenNMSE1,fileMenupre,fileMenucpm;  //�ع�������
    private JMenuItem fileMenu11,fileMenu12,fileMenu13;  //�ڵ���Ϣ
    private JMenuItem helpauthor,helpMenuhe;   //�༭�˵��Ĳ˵���  
    //��������Ա��������  
    private JToolBar toolBar;   //���߰�  
    private JButton b1,b2,b3;//����1����ť 
    final  Font f=new Font("sanserif",Font.PLAIN,12); 
    ///����Rserve��;
    private RService rService;
    public Rtest() throws REXPMismatchException, REngineException{   
    	super("����ѧϰ--������");
    	////////����ͼ��
    	try {
    	     String src = "/image/logo.png";     //ͼƬ·��
    	     Image image=ImageIO.read(this.getClass().getResource(src));
    	        this.setIconImage(image);        //����ͼ��
    	       } catch (IOException e) {
    	        e.printStackTrace();
    	    } 
    	/////////////////////////////////////////////////////////////
    	mb = new JMenuBar();    //�����˵���  
        fileMenu = new JMenu("����(R)");//�����˵�  
        fileMenuRun = new JMenuItem("�ع���"); 
        fileMenuNMSE= new JMenuItem("�鿴��֦ǰ��NMSE��NMSE0��Ϣ");
        fileMenucp= new JMenuItem("�鿴CP�ĸ�����Ϣ");
        fileMenucpm= new JMenuItem("CP����Сֵ");
        fileMenNMSE1= new JMenuItem("�鿴��֦���NMSE��NMSE0��Ϣ");  
        fileMenupre= new JMenuItem("��ʵֵ��Ԥ��ֵ�Ƚ�");
        fileMenu.add(fileMenuRun);
        fileMenu.addSeparator(); //���ӷָ���;
        fileMenu.add(fileMenucp);
        fileMenu.add(fileMenucpm);
        fileMenu.addSeparator(); //���ӷָ���;
        fileMenu.add(fileMenuNMSE);
        fileMenu.add(fileMenNMSE1);
        fileMenu.addSeparator(); 
        fileMenu.add(fileMenupre); 
        fileMenucp.setEnabled(false);
        fileMenucpm.setEnabled(false);
        fileMenuNMSE.setEnabled(false);
        fileMenNMSE1.setEnabled(false);
        fileMenupre.setEnabled(false);
        //ͼƬ��ʾ;
        fileMenu1 = new JMenu("�ڵ���Ϣ(J)");//�����ڵ���Ϣ
        fileMenu11= new JMenuItem("��֦ǰ�Ľڵ�ͼ");
        fileMenu12= new JMenuItem("��֦��Ľڵ�ͼ");
        fileMenu13= new JMenuItem("��ʵֵ��Ԥ��ֵ�Ա�ͼ");
        fileMenu1.add(fileMenu11);
        fileMenu1.add(fileMenu12);
        fileMenu1.addSeparator();
        fileMenu1.add(fileMenu13);
        fileMenu11.setEnabled(false);
        fileMenu12.setEnabled(false);
        fileMenu13.setEnabled(false);
        ///����
        helpMenu = new JMenu("����(H)");  
        helpauthor = new JMenuItem("����(A) Ctrl+A");  
        helpMenuhe = new JMenuItem("����(H) Ctrl+H");   
        helpMenu.add(helpauthor);
        helpMenu.addSeparator();
        helpMenu.add(helpMenuhe);   
        //���˵�ȫ�����Ӳ˵�����  
        mb.add(fileMenu);
        mb.add(fileMenu1);
        mb.add(helpMenu); 
        //��������ʵ��   
        toolBar =new JToolBar();    //�������߰�  
        b1= new JButton(new ImageIcon("img/1.png"));  
        b2= new JButton(new ImageIcon("img/3.png"));
        b3= new JButton(new ImageIcon("img/2.png")); 
        //�Ѱ�ťȫ�����ӵ����߰���  
        toolBar.add(b1); 
        toolBar.add(b2); 
        toolBar.add(b3); 
        b3.setEnabled(false);
        //�Ѳ˵������������������˵����ӵ��������  
        setJMenuBar(mb);  
        add(toolBar,BorderLayout.NORTH);  
    	//////���岼��;
        setLayout(new FlowLayout(FlowLayout.LEADING));
        setSize(650, 650);
        setResizable(true);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setVisible(true);  
        show.setEditable(false);
        add(show);
        add(hc);add(hc1);
        add(jLabel1);
        /////���ù������������ӵ��������;
        add(new JScrollPane(show)); 
        hc.setVisible(false);hc1.setVisible(false);
        jLabel1.setVisible(false);
        ////����Ĭ���ļ���;
        File file1 = new File("c:\\datacy");
        file1.mkdirs();
        file1 = new File("c:\\datacy");
        file1.mkdir();
        /////�ع�������;
        fileMenuRun.addActionListener(new ActionListener() {
        public void actionPerformed(ActionEvent e) { 
        	show.setText(" ");
        	rService = new RService();
     		final RConnection re = rService.startTransaction(); // ��ʼ��ռ�����ռ� 
     		try {	
     			REXP c1=re.eval("library(lars)");
     			//REXP c2=re.eval("data(diabetes)");
     			REXP c3=re.eval("dataset<-diabetes");
     			REXP c4=re.eval("#�鿴�����Լ�����");
     			REXP c5=re.eval("s<-str(diabetes)");
     			REXP c6=re.eval("#�鿴�������ݼ�");
     			REXP c8=re.eval("#���������");
     			REXP c9=re.eval("w<-diabetes[,2:3]");
     			REXP c10=re.eval("library(rpart.plot)");
     			REXP c11=re.eval("reg<-rpart(y~.,w)  ");
     			re.eval("jpeg('c:/datacy/test1.jpg')");
     			re.eval("rpart.plot(reg,type=4,faclen=T)");
     			re.eval("dev.off()");
     			REXP c13=re.eval("#�鿴����ڵ�");
     			re.eval("p<-print(reg)");
     			REXP c15=re.eval("#������֤");
     			REXP c16=re.eval("w<-diabetes[,2:3]  ");
     			REXP c17=re.eval("n<-length(w$y)  ");
     			REXP c18=re.eval("index1<-1:n  ");
     			REXP c19=re.eval("index2<-rep(1:5,ceiling(n/5))[1:n]  ");
     			REXP c20=re.eval("#��n�������������ȡn/5��������Ϊ���Լ�;");
     			REXP c21=re.eval("index2<-sample(index2,n)");
     			REXP c22=re.eval("NMSE<-rep(0,5)");
     			REXP c23=re.eval("NMSE0<-NMSE");
     			REXP c24=re.eval("for(i in 1:5){m<-index1[index2==i];reg<-rpart(y~.,w[-m,]);y0<-predict(reg,w[-m,]);y1<-predict(reg,w[m,]);NMSE0[i]<-mean((w$y[-m]-y0)^2)/mean((w$y[-m]-mean(w$y[-m]))^2);NMSE[i]<-mean((w$y[m]-y1)^2)/mean((w$y[m]-mean(w$y[m]))^2);}");
     			REXP C241=re.eval("nmse<-data.frame(NMSE,NMSE0)");
     			///��NMSEд��;
     			REXP c331=re.eval("write.csv(nmse,\"c:/datacy/NMSE.csv\")");
     			REXP c34=re.eval("#�鿴cpֵ");
     			///�鿴cpֵ;
     			REXP c35=re.eval("cp<-reg$cptable");
     			REXP c351=re.eval("write.csv(cp,\"c:/datacy/cp.csv\")");
     			REXP c36=re.eval("#���м�֦");
     			REXP c37=re.eval("reg2<-prune(reg,cp=reg$cptable[which.min(reg$cptable[,\"xerror\"]),\"CP\"]) ");
     			REXP c370=re.eval("cp=reg$cptable[which.min(reg$cptable[,\"xerror\"]),\"CP\"]");
     			re.eval("jpeg('c:/datacy/test2.jpg')");
     			re.eval("rpart.plot(reg2,type=2,faclen=T)");
     			re.eval("dev.off()");
     			REXP c39=re.eval("#��֦��Ľ�����֤");
     			REXP c40=re.eval("w<-diabetes[,2:3]");
     			REXP c41=re.eval("n<-length(w$y)  ");
     			REXP c42=re.eval("index1<-1:n");
     			REXP c43=re.eval("index2<-rep(1:5,ceiling(n/5))[1:n]  ");
     			REXP c44=re.eval("#��n�������������ȡn/5��������Ϊ���Լ�;");
     			REXP c45=re.eval("index2<-sample(index2,n)  ");
     			REXP c46=re.eval("NMSE<-rep(0,5)  ");
     			REXP c47=re.eval("NMSE0<-NMSE");
     			REXP c48=re.eval("for(i in 1:5){m<-index1[index2==i];reg<-rpart(y~.,w[-m,]);y0<-predict(reg2,w[-m,]);y1<-predict(reg2,w[m,]);NMSE0[i]<-mean((w$y[-m]-y0)^2)/mean((w$y[-m]-mean(w$y[-m]))^2);NMSE[i]<-mean((w$y[m]-y1)^2)/mean((w$y[m]-mean(w$y[m]))^2);}");
     			REXP c55=re.eval("NMSE1<-data.frame(NMSE,NMSE0)");
     			///��NMSEд��;
     			REXP c551=re.eval("write.csv(NMSE1,\"c:/datacy/NMSE1.csv\")");
     			REXP c57=re.eval("#�ع�������Ԥ��");
     			REXP c58=re.eval("predata<-predict(reg2,data=w)");
     			REXP c59=re.eval("realdata<-w$y[c(1:354)]");
     			REXP c590=re.eval("predata<-ceiling(predata)");
     			REXP c60=re.eval("pre<-data.frame(predata,realdata)");
     			//���Ԥ��ֵ����ʵֵ;
     			REXP c601=re.eval("write.csv(pre,\"c:/datacy/pre.csv\")");
     			//���Ԥ��ֵ����ʵֵ�ĶԱ�ͼ;
     			re.eval("jpeg('c:/datacy/test3.jpg')");
     			REXP c602=re.eval("arange <- range(0,realdata,predata);plot(realdata,type=\"o\",col=\"blue\",ylim=arange,ann=FALSE);lines(predata, type=\"o\", pch=22, lty=2, col=\"red\");title(xlab=\"order_num\",col.lab=rgb(0,0.5,0));title(ylab=\" \",col.lab=rgb(0,0.5,0));legend(1,arange[2],c(\"realdata\",\"predata\"),cex=0.7,col=c(\"blue\",\"red\"),pch=21:22,lty=1:2)");
     			re.eval("dev.off()");
     			re.close();
     			//System.out.println(c55.asString());
     			hc.setText(c370.asString());
     		} catch (Exception y) {
     			System.out.println("Failed to create temp file" +y);
     			y.printStackTrace();
     		} finally {	
     		}
        	show.setText("�ع���������������ϣ�����Ҫ������Ϊ��CP��Ϣ,NMSE��Ϣ�Լ��ڵ�ͼ");
        	fileMenucp.setEnabled(true);
            fileMenuNMSE.setEnabled(true);
            fileMenNMSE1.setEnabled(true);
            fileMenupre.setEnabled(true);
            fileMenu11.setEnabled(true);
            fileMenu12.setEnabled(true);
            fileMenu13.setEnabled(true);
            fileMenucpm.setEnabled(true);
            }
        }); 
      ///�鿴NMSE����;
        fileMenuNMSE.addActionListener(new ActionListener() {
    	        public void actionPerformed(ActionEvent e) {
    	    		try{show.read(new FileReader("c:/datacy/NMSE.csv"),null);}  
    	                catch(IOException s){}
         			BufferedWriter bw = null;
                    try {
                        OutputStream os = new FileOutputStream("c:/datacy/NMSE.csv");
                        bw = new BufferedWriter(new OutputStreamWriter(os));
                        for (String value : show.getText().split("\n")) {
                            bw.write(value);
                            bw.newLine();//����
                        }
                    } catch (IOException e1) {
                    } finally {
                        if (bw != null) {
                            try {
                                bw.close();
                            } catch (IOException e1) {}
                        }
                    }
    	        }
    	 }
        );
      ///�鿴Ԥ��ֵ����ʵֵ����;
        fileMenupre.addActionListener(new ActionListener() {
    	        public void actionPerformed(ActionEvent e) {
    	    		try{show.read(new FileReader("c:/datacy/pre.csv"),null);}  
    	                catch(IOException s){}
         			BufferedWriter bw = null;
                    try {
                        OutputStream os = new FileOutputStream("c:/datacy/pre.csv");
                        bw = new BufferedWriter(new OutputStreamWriter(os));
                        for (String value : show.getText().split("\n")) {
                            bw.write(value);
                            bw.newLine();//����
                        }
                    } catch (IOException e1) {
                    } finally {
                        if (bw != null) {
                            try {
                                bw.close();
                            } catch (IOException e1) {}
                        }
                    }
    	        }
    	 }
        );
         ///�鿴NMSE1����;
        fileMenNMSE1.addActionListener(new ActionListener() {
    	        public void actionPerformed(ActionEvent e) {
    	    		try{show.read(new FileReader("c:/datacy/NMSE1.csv"),null);}  
    	                catch(IOException s){}
         			BufferedWriter bw = null;
                    try {
                        OutputStream os = new FileOutputStream("c:/datacy/NMSE1.csv");
                        bw = new BufferedWriter(new OutputStreamWriter(os));
                        for (String value : show.getText().split("\n")) {
                            bw.write(value);
                            bw.newLine();//����
                        }
                    } catch (IOException e1) {
                    } finally {
                        if (bw != null) {
                            try {
                                bw.close();
                            } catch (IOException e1) {}
                        }
                    }
    	        }
    	 }
        );
    ///�鿴cpֵ;
    fileMenucp.addActionListener(new ActionListener() {
	        public void actionPerformed(ActionEvent e) {
	    		try{show.read(new FileReader("c:/datacy/cp.csv"),null);}  
	                catch(IOException s){}
     			BufferedWriter bw = null;
                try {
                    OutputStream os = new FileOutputStream("c:/datacy/cp.csv");
                    bw = new BufferedWriter(new OutputStreamWriter(os));
                    for (String value : show.getText().split("\n")) {
                        bw.write(value);
                        bw.newLine();//����
                    }
                } catch (IOException e1) {
                } finally {
                    if (bw != null) {
                        try {
                            bw.close();
                        } catch (IOException e1) {}
                    }
                }
	        }
	 }
    );
    ///�鿴��С��cpֵ;
    fileMenucpm.addActionListener(new ActionListener() {
	        public void actionPerformed(ActionEvent e) {
	    		show.setText("��С��CPֵΪ��"+"\n"+hc.getText());
	 }
    }
    );
      //�ļ���ȡ;
    b1.addActionListener(new ActionListener() {
	        public void actionPerformed(ActionEvent e) {
	        	JFileChooser jfc=new JFileChooser();
	        	jfc.setFileSelectionMode(JFileChooser.FILES_AND_DIRECTORIES);
	    		jfc.showDialog(new JLabel(), "ѡ���ļ���");
	    		File file=jfc.getSelectedFile();
	    		try{show.read(new FileReader(file),null);}  
	                catch(IOException s){}
     			BufferedWriter bw = null;
                try {
                    OutputStream os = new FileOutputStream(file);
                    bw = new BufferedWriter(new OutputStreamWriter(os));
                    for (String value : show.getText().split("\n")) {
                        bw.write(value);
                        bw.newLine();//����
                    }
                } catch (IOException e1) {
                } finally {
                    if (bw != null) {
                        try {
                            bw.close();
                        } catch (IOException e1) {}
                    }
                }
	        }
	 }
    );
    /////������Ϣ;
    helpauthor.addActionListener(new ActionListener() {
        public void actionPerformed(ActionEvent e) {
        	String value="���ߣ��ű�"+"\n"+"�����ƾ���ѧ"+"\n"+"��Ȩ����";
        	int n = JOptionPane.showConfirmDialog(null, value, "��������", JOptionPane.YES_NO_OPTION);   
        }
 }
);
    /////������Ϣ;
    helpMenuhe.addActionListener(new ActionListener() {
        public void actionPerformed(ActionEvent e) {
        	show.setText("���ڴ򿪰����ĵ������Ժ�...");
        	try {
				Runtime.getRuntime().exec("cmd /c start http:binmen.github.io/cy");
				show.setText("�����ĵ��Ѵ򿪣���");
			} catch (IOException e1) {
				e1.printStackTrace();
			}
        }
 }  
);
    /////��֦ǰ�Ľڵ�ͼ��ȡ;
    fileMenu11.addActionListener(new ActionListener() {
        public void actionPerformed(ActionEvent e) {
        	jLabel1.setVisible(true);
 			int width = 630; 
 			int height = 450;
 		    ImageIcon pic1 = new ImageIcon("c:/datacy/test1.jpg");
 		    pic1.setImage(pic1.getImage().getScaledInstance(width,height,Image.SCALE_DEFAULT));
 		    jLabel1.setIcon(pic1);
 	        add(jLabel1);
        }
 }
);
    /////��֦��Ľڵ�ͼ��ȡ;
    fileMenu12.addActionListener(new ActionListener() {
        public void actionPerformed(ActionEvent e) {
        	jLabel1.setVisible(true);
 			int width = 630; 
 			int height = 450;
 		    ImageIcon pic1 = new ImageIcon("c:/datacy/test2.jpg");
 		    pic1.setImage(pic1.getImage().getScaledInstance(width,height,Image.SCALE_DEFAULT));
 		    jLabel1.setIcon(pic1);
 	        add(jLabel1);
        }
 }
);
    /////��ʵֵ��Ԥ��ֵ�Ա�ͼ;
    fileMenu13.addActionListener(new ActionListener() {
        public void actionPerformed(ActionEvent e) {
        	jLabel1.setVisible(true);
 			int width = 630; 
 			int height = 480;
 		    ImageIcon pic1 = new ImageIcon("c:/datacy/test3.jpg");
 		    pic1.setImage(pic1.getImage().getScaledInstance(width,height,Image.SCALE_DEFAULT));
 		    jLabel1.setIcon(pic1);
 	        add(jLabel1);
        }
 }
);
/////�ع�������;
    b2.addActionListener(new ActionListener() {
    public void actionPerformed(ActionEvent e) { 
    	show.setText(" ");
    	rService = new RService();
 		final RConnection re = rService.startTransaction(); // ��ʼ��ռ�����ռ� 
 		try {	
 			REXP c1=re.eval("library(lars)");
 			//REXP c2=re.eval("data(diabetes)");
 			REXP c3=re.eval("dataset<-diabetes");
 			REXP c4=re.eval("#�鿴�����Լ�����");
 			REXP c5=re.eval("s<-str(diabetes)");
 			REXP c6=re.eval("#�鿴�������ݼ�");
 			REXP c8=re.eval("#���������");
 			REXP c9=re.eval("w<-diabetes[,2:3]");
 			REXP c10=re.eval("library(rpart.plot)");
 			REXP c11=re.eval("reg<-rpart(y~.,w)  ");
 			re.eval("jpeg('c:/datacy/test1.jpg')");
 			re.eval("rpart.plot(reg,type=4,faclen=T)");
 			re.eval("dev.off()");
 			REXP c13=re.eval("#�鿴����ڵ�");
 			re.eval("p<-print(reg)");
 			REXP c15=re.eval("#������֤");
 			REXP c16=re.eval("w<-diabetes[,2:3]  ");
 			REXP c17=re.eval("n<-length(w$y)  ");
 			REXP c18=re.eval("index1<-1:n  ");
 			REXP c19=re.eval("index2<-rep(1:5,ceiling(n/5))[1:n]  ");
 			REXP c20=re.eval("#��n�������������ȡn/5��������Ϊ���Լ�;");
 			REXP c21=re.eval("index2<-sample(index2,n)");
 			REXP c22=re.eval("NMSE<-rep(0,5)");
 			REXP c23=re.eval("NMSE0<-NMSE");
 			REXP c24=re.eval("for(i in 1:5){m<-index1[index2==i];reg<-rpart(y~.,w[-m,]);y0<-predict(reg,w[-m,]);y1<-predict(reg,w[m,]);NMSE0[i]<-mean((w$y[-m]-y0)^2)/mean((w$y[-m]-mean(w$y[-m]))^2);NMSE[i]<-mean((w$y[m]-y1)^2)/mean((w$y[m]-mean(w$y[m]))^2);}");
 			REXP C241=re.eval("nmse<-data.frame(NMSE,NMSE0)");
 			///��NMSEд��;
 			REXP c331=re.eval("write.csv(nmse,\"c:/datacy/NMSE.csv\")");
 			REXP c34=re.eval("#�鿴cpֵ");
 			///�鿴cpֵ;
 			REXP c35=re.eval("cp<-reg$cptable");
 			REXP c351=re.eval("write.csv(cp,\"c:/datacy/cp.csv\")");
 			REXP c36=re.eval("#���м�֦");
 			REXP c37=re.eval("reg2<-prune(reg,cp=reg$cptable[which.min(reg$cptable[,\"xerror\"]),\"CP\"]) ");
 			REXP c370=re.eval("cp=reg$cptable[which.min(reg$cptable[,\"xerror\"]),\"CP\"]");
 			re.eval("jpeg('c:/datacy/test2.jpg')");
 			re.eval("rpart.plot(reg2,type=2,faclen=T)");
 			re.eval("dev.off()");
 			REXP c39=re.eval("#��֦��Ľ�����֤");
 			REXP c40=re.eval("w<-diabetes[,2:3]");
 			REXP c41=re.eval("n<-length(w$y)  ");
 			REXP c42=re.eval("index1<-1:n");
 			REXP c43=re.eval("index2<-rep(1:5,ceiling(n/5))[1:n]  ");
 			REXP c44=re.eval("#��n�������������ȡn/5��������Ϊ���Լ�;");
 			REXP c45=re.eval("index2<-sample(index2,n)  ");
 			REXP c46=re.eval("NMSE<-rep(0,5)  ");
 			REXP c47=re.eval("NMSE0<-NMSE");
 			REXP c48=re.eval("for(i in 1:5){m<-index1[index2==i];reg<-rpart(y~.,w[-m,]);y0<-predict(reg2,w[-m,]);y1<-predict(reg2,w[m,]);NMSE0[i]<-mean((w$y[-m]-y0)^2)/mean((w$y[-m]-mean(w$y[-m]))^2);NMSE[i]<-mean((w$y[m]-y1)^2)/mean((w$y[m]-mean(w$y[m]))^2);}");
 			REXP c55=re.eval("NMSE1<-data.frame(NMSE,NMSE0)");
 			///��NMSEд��;
 			REXP c551=re.eval("write.csv(NMSE1,\"c:/datacy/NMSE1.csv\")");
 			REXP c57=re.eval("#�ع�������Ԥ��");
 			REXP c58=re.eval("predata<-predict(reg2,data=w)");
 			REXP c59=re.eval("realdata<-w$y[c(1:354)]");
 			REXP c590=re.eval("predata<-ceiling(predata)");
 			REXP c60=re.eval("pre<-data.frame(predata,realdata)");
 			//���Ԥ��ֵ����ʵֵ;
 			REXP c601=re.eval("write.csv(pre,\"c:/datacy/pre.csv\")");
 			//���Ԥ��ֵ����ʵֵ�ĶԱ�ͼ;
 			re.eval("jpeg('c:/datacy/test3.jpg')");
 			REXP c602=re.eval("arange <- range(0,realdata,predata);plot(realdata,type=\"o\",col=\"blue\",ylim=arange,ann=FALSE);lines(predata, type=\"o\", pch=22, lty=2, col=\"red\");title(xlab=\"order_num\",col.lab=rgb(0,0.5,0));title(ylab=\" \",col.lab=rgb(0,0.5,0));legend(1,arange[2],c(\"realdata\",\"predata\"),cex=0.7,col=c(\"blue\",\"red\"),pch=21:22,lty=1:2)");
 			re.eval("dev.off()");
 			re.close();
 			//System.out.println(c55.asString());
 			hc.setText(c370.asString());
 		} catch (Exception y) {
 			System.out.println("Failed to create temp file" +y);
 			y.printStackTrace();
 		} finally {	
 		}
    	show.setText("�ع���������������ϣ�����Ҫ������Ϊ��CP��Ϣ,NMSE��Ϣ�Լ��ڵ�ͼ");
    	fileMenucp.setEnabled(true);
        fileMenuNMSE.setEnabled(true);
        fileMenNMSE1.setEnabled(true);
        fileMenupre.setEnabled(true);
        fileMenu11.setEnabled(true);
        fileMenu12.setEnabled(true);
        fileMenu13.setEnabled(true);
        fileMenucpm.setEnabled(true);
        }
    });
} 
public static void main(String[] args) throws REXPMismatchException,REngineException{
         new Rtest();
    }
}