package rserver.function;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.FileSystemXmlApplicationContext;
import org.testng.SkipException;


public abstract class RTestBase {

	private static final Logger logger = LoggerFactory.getLogger(RTestBase.class);
	
	protected final String CONTEXT_XML = "src/main/webapp/WEB-INF/application.xml";
	
	protected ApplicationContext context;
	
	protected RService rService;
	
	public void setUpContext() {
		this.context = new FileSystemXmlApplicationContext(CONTEXT_XML);
		logger.debug(this.getClass().getSimpleName() + " - Spring context set up");
	}
	
	public void tearDownContext() {
		((FileSystemXmlApplicationContext)this.context).close();
		logger.debug(this.getClass().getSimpleName() + " - Spring context closed");
	}
	
	public void setUpRService() {
		this.rService = this.getBean(RService.class);
		try {
			this.rService.startTransaction();
		} catch (RServiceNotAvailableException e) {
			throw new SkipException("Rserve is not started. Tests will be skipped.");
		} finally {
			this.rService.endTransaction();
		}
		logger.info("R service is ready for connection");
	}
	
	public void tearDownRService() {
		this.rService.finalize();
		logger.debug("R service torn down");
	}
	
	public <T> T getBean(Class<T> clazz) {
		return clazz.cast(this.context.getBeansOfType(clazz));
	}
	
}
