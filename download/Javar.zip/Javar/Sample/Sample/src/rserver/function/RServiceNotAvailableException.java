package rserver.function;


public class RServiceNotAvailableException extends RuntimeException {
	
	private static final long serialVersionUID = 1L;

	public RServiceNotAvailableException(String msg, Throwable cause) {
		super(msg, cause);
	}

}
