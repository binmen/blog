package rserver.function;


import org.rosuda.REngine.Rserve.RConnection;
import org.rosuda.REngine.Rserve.RserveException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class RService {

	private static final Logger logger = LoggerFactory.getLogger(RService.class);
	
	private RConnection conn;
	
	private boolean inActiveTransaction;
	
	public synchronized RConnection startTransaction() {
		if(conn==null) {
			logger.info("No existing connection found");
			conn = createRConnection();
			logger.info("created new R connection");
		}
		
		synchronized(conn) {
			while(inActiveTransaction) {
				try {
					conn.wait();
				} catch (InterruptedException e) {
					throw new RuntimeException(e);
				}
			}
		}
		inActiveTransaction = true;
		logger.info("got lock of R connection");
		return conn;
	}
	
	public void endTransaction() {
		if(conn==null) {
			return;
		}
		
		inActiveTransaction = false;
		synchronized(conn) {
			try {
				conn.voidEval("rm(list=ls())");
			} catch (RserveException e) {
				logger.warn("Failed to clear workspace: " + e.getMessage());
			}
			conn.notifyAll();
			logger.debug("released R connection");
		}
	}

	private synchronized RConnection createRConnection() {
		if(conn==null) {
			try {
				conn = new RConnection();
			} catch (RserveException e) {
				throw new RServiceNotAvailableException("Failed to create R connection. Please check RServer is started", e);
			}
		}
		return conn;		
	}
	
	public void finalize() {
		if(conn!=null) {
			conn.close();
		}
	}

	public RConnection getConn() {
		return conn;
	}

	public void setConn(RConnection conn) {
		this.conn = conn;
	}
	
	
}
