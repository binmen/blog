package rserver.function;


import org.rosuda.REngine.REXPMismatchException;
import org.rosuda.REngine.Rserve.RConnection;
import org.rosuda.REngine.Rserve.RserveException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

//import util.AppUtils;

public class RServiceTest extends RTestBase {
	
	private static final Logger logger = LoggerFactory.getLogger(RServiceTest.class);

	private StringBuffer results = new StringBuffer();
	
	@BeforeMethod
	public void setUp() {
		super.setUpContext();
		super.setUpRService();
	}
	
	@AfterMethod
	public void tearDown() {
		super.tearDownRService();
		super.tearDownContext();
	}
	
	
	//--------------------------- Tests
	

	@Test
	public void testSyncedTransaction() throws InterruptedException, RserveException, REXPMismatchException {
		Thread[] group = new Thread[5];
		for(Thread th : group) {
			th = new Thread(new TestThread());
			th.start();
			Thread.sleep(500);
		}
		Thread.sleep(10000);
		
		logger.debug("Sequence:" + results.toString());
		Assert.assertTrue(results.length() > 0);
		Assert.assertTrue(results.toString().startsWith("012340123401234"));
	}

	class TestThread implements Runnable {
		
		final RService rService = RServiceTest.this.rService;
		
		public void run() {
			logger.debug("Thread started");
			RConnection r = rService.startTransaction();
			logger.debug("Thread got transaction");
			try {
				r.eval("1+2");
			} catch (RserveException e1) {
				rService.endTransaction();
				//throw AppUtils.newRuntimeException(null, e1);
			}
			
			int count = 0;
			while(count<5) {
				try {
					Thread.sleep(500);
					results.append(String.valueOf(count++));
				} catch (InterruptedException e) {
					//throw AppUtils.newRuntimeException(null, e);
				}
			}
			
			rService.endTransaction();
			logger.debug("Thread ended");
		}
		
		
	}

}

